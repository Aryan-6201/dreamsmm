"use client";

import { useEffect, useState } from "react";

type Service = {
  id: number;
  name: string;
  platform: string;
  category: string | null;
  description: string | null;
  rate: string;
  min: number;
  max: number;
  enabled: boolean;
  refill: boolean;
  providerId: string | null;
  providerName: string | null;
};
type Category = {
  id: number;
  name: string;
  platform: string;
  enabled: boolean;
  sortOrder: number;
};

type ImportedProviderService = {
  averageTime?: string | number | null;
  service: string;
  name: string;
  type?: string;
  category?: string;
  description?: string;
  rate: string;
  min: number;
  max: number;
  refill?: boolean | string;
};

type FormState = {
  name: string;
  platform: string;
  category: string;
  description: string;
  rate: string;
  min: string;
  max: string;
  enabled: boolean;
  refill: boolean;
  providerId: string;
  providerName: string;
};

const emptyForm: FormState = {
  name: "",
  platform: "",
  category: "",
  description: "",
  rate: "",
  min: "",
  max: "",
  enabled: true,
  refill: false,
  providerId: "",
  providerName: "",
};

const inputClass =
  "w-full rounded-xl border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm text-gray-900 outline-none placeholder:text-slate-500 focus:border-blue-500/40";

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-xs font-medium text-slate-500">
        {label}
      </span>
      {children}
    </label>
  );
}

export default function AdminServicesPage() {
  const [services, setServices] = useState<Service[]>([]);
  const [selectedServiceIds, setSelectedServiceIds] = useState<string[]>([]);
  const [bulkDeleting, setBulkDeleting] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [showCreateCategory, setShowCreateCategory] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState("");
  const [newCategoryPlatform, setNewCategoryPlatform] = useState("Other");

  const [form, setForm] = useState<FormState>(emptyForm);
  const [editingId, setEditingId] = useState<number | null>(null);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [message, setMessage] = useState("");

  const [providerServiceId, setProviderServiceId] = useState("");
  const [providerMarkup, setProviderMarkup] = useState("");
  const [providerAutoSync, setProviderAutoSync] = useState(true);
  const [importing, setImporting] = useState(false);
  const [importedService, setImportedService] =
    useState<ImportedProviderService | null>(null);

  async function loadServices() {
    setLoading(true);

    try {
      const response = await fetch("/api/admin/services", {
        cache: "no-store",
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Unable to load services.");
      }

      setServices(data.services || []);
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Unable to load services."
      );
    } finally {
      setLoading(false);
    }
  }
  async function loadCategories() {
  try {
    const response = await fetch("/api/categories", {
      cache: "no-store",
    });

    const data = await response.json();

    if (response.ok) {
      setCategories(data.categories || []);
    }
  } catch (error) {
    console.error("Failed to load categories:", error);
  }
}

useEffect(() => {
  loadServices();
  loadCategories();
}, []);

  async function createCategory() {
    const name = newCategoryName.trim();

    if (!name) {
      setMessage("Enter a category name.");
      return;
    }

    try {
      const response = await fetch("/api/categories/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name,
          platform: newCategoryPlatform,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Unable to create category.");
      }

      setCategories((current) => [...current, data.category]);
      updateForm("category", data.category.name);
      setNewCategoryName("");
      setShowCreateCategory(false);
      setMessage("Category created successfully.");
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Unable to create category."
      );
    }
  }
  function updateForm<K extends keyof FormState>(
    key: K,
    value: FormState[K]
  ) {
    setForm((current) => ({
      ...current,
      [key]: value,
    }));
  }

  function resetForm() {
    setEditingId(null);
    setForm(emptyForm);
  }

  function startEdit(service: Service) {
    setEditingId(service.id);

    setForm({
      name: service.name,
      platform: service.platform,
      category: service.category || "",
      description: service.description || "",
      rate: service.rate,
      min: String(service.min),
      max: String(service.max),
      enabled: service.enabled,
      refill: service.refill,
      providerId: service.providerId || "",
      providerName: service.providerName || "",
    });

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  }

  async function fetchProviderService() {
    const serviceId = providerServiceId.trim();

    if (!serviceId) {
      setMessage("Enter a MicoSMM service ID first.");
      return;
    }

    setImporting(true);
    setMessage("");
    setImportedService(null);

    try {
      const response = await fetch("/api/admin/micosmm-import", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "fetch",
          serviceId,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Unable to fetch provider service.");
      }

      setImportedService(data.service);
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Unable to fetch provider service."
      );
    } finally {
      setImporting(false);
    }
  }

  async function importProviderService() {
    if (!importedService) return;

    const markup = Number(providerMarkup);

    if (!Number.isFinite(markup) || markup < 0) {
      setMessage("Enter a valid markup percentage.");
      return;
    }

    setImporting(true);
    setMessage("");

    try {
      const response = await fetch("/api/admin/micosmm-import", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "import",
          serviceId: importedService.service,
          markupPercent: markup,
          autoSync: providerAutoSync,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Unable to import provider service.");
      }

      setMessage(
        `Service #${data.service.id} imported successfully at Î“Ã©â•£${data.service.rate}/1k.`
      );
      setProviderServiceId("");
      setProviderMarkup("");
      setImportedService(null);
      await loadServices();
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Unable to import provider service."
      );
    } finally {
      setImporting(false);
    }
  }
  const [mkapiService, setMkapiService] =
    useState<ImportedProviderService | null>(null);
  const [mkapiServiceId, setMkapiServiceId] = useState("");
  const [mkapiMarkup, setMkapiMarkup] = useState("25");
  const [mkapiAutoSync, setMkapiAutoSync] = useState(true);
  const [mkapiImporting, setMkapiImporting] = useState(false);
  const [mkapiResult, setMkapiResult] = useState("");

  const [vipsmmService, setVipsmmService] =
    useState<ImportedProviderService | null>(null);
  const [vipsmmServiceId, setVipsmmServiceId] = useState("");
  const [vipsmmMarkup, setVipsmmMarkup] = useState("25");
  const [vipsmmAutoSync, setVipsmmAutoSync] = useState(true);
  const [vipsmmImporting, setVipsmmImporting] = useState(false);
  const [vipsmmResult, setVipsmmResult] = useState("");

  const [smmgenService, setSmmgenService] =
    useState<ImportedProviderService | null>(null);
  const [smmgenServiceId, setSmmgenServiceId] = useState("");
  const [smmgenMarkup, setSmmgenMarkup] = useState("25");
  const [smmgenAutoSync, setSmmgenAutoSync] = useState(true);
  const [smmgenImporting, setSmmgenImporting] = useState(false);
  const [smmgenResult, setSmmgenResult] = useState("");

  async function fetchMkapiService() {
    const serviceId = mkapiServiceId.trim();

    if (!serviceId) {
      setMessage("Enter a MKAPI service ID first.");
      return;
    }

    setMkapiImporting(true);
    setMessage("");
    setMkapiService(null);

    try {
      const response = await fetch("/api/admin/mkapi-import", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "fetch",
          serviceId,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "Unable to fetch MKAPI service."
        );
      }

      setMkapiService({ ...data.service, averageTime: data.service.average_time ?? null });
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Unable to fetch MKAPI service."
      );
    } finally {
      setMkapiImporting(false);
    }
  }

  async function importMkapiService() {
    if (!mkapiService) return;

    const markup = Number(mkapiMarkup);

    if (!Number.isFinite(markup) || markup < 0 || markup > 1000) {
      setMessage("Enter a valid markup percentage.");
      return;
    }

    setMkapiImporting(true);
    setMessage("");

    try {
      const response = await fetch("/api/admin/mkapi-import", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "import",
          serviceId: mkapiService.service,
          markupPercent: markup,
          autoSync: mkapiAutoSync,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "Unable to import MKAPI service."
        );
      }

      setMessage("MKAPI service imported successfully.");
      setMkapiServiceId("");
      setMkapiMarkup("");
      setMkapiService(null);

      await loadServices();
      await loadCategories();
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Unable to import MKAPI service."
      );
    } finally {
      setMkapiImporting(false);
    }
  }
  async function fetchVipsmmService() {
    const serviceId = vipsmmServiceId.trim();

    if (!serviceId) {
      setMessage("Enter a VIPSMM service ID first.");
      return;
    }

    setVipsmmImporting(true);
    setMessage("");
    setVipsmmService(null);

    try {
      const response = await fetch("/api/admin/vipsmm-import", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "fetch",
          serviceId,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "Unable to fetch VIPSMM service."
        );
      }

      setVipsmmService({ ...data.service, averageTime: data.service.average_time ?? null });
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Unable to fetch VIPSMM service."
      );
    } finally {
      setVipsmmImporting(false);
    }
  }

  async function importVipsmmService() {
    if (!vipsmmService) return;

    const markup = Number(vipsmmMarkup);

    if (!Number.isFinite(markup) || markup < 0 || markup > 1000) {
      setMessage("Enter a valid markup percentage.");
      return;
    }

    setVipsmmImporting(true);
    setMessage("");

    try {
      const response = await fetch("/api/admin/vipsmm-import", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "import",
          serviceId: vipsmmService.service,
          markupPercent: markup,
          autoSync: vipsmmAutoSync,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "Unable to import VIPSMM service."
        );
      }

      setMessage("VIPSMM service imported successfully.");
      setVipsmmServiceId("");
      setVipsmmMarkup("");
      setVipsmmService(null);

      await loadServices();
      await loadCategories();
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Unable to import VIPSMM service."
      );
    } finally {
      setVipsmmImporting(false);
    }
  }
  async function fetchSmmgenService() {
    const serviceId = smmgenServiceId.trim();

    if (!serviceId) {
      setMessage("Enter a SMMGen service ID first.");
      return;
    }

    setSmmgenImporting(true);
    setMessage("");
    setSmmgenService(null);

    try {
      const response = await fetch("/api/admin/smmgen-import", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "fetch",
          serviceId,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "Unable to fetch SMMGen service."
        );
      }

      setSmmgenService({
        ...data.service,
        averageTime: data.service.average_time ?? null,
      });
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Unable to fetch SMMGen service."
      );
    } finally {
      setSmmgenImporting(false);
    }
  }

  async function importSmmgenService() {
    if (!smmgenService) return;

    const markup = Number(smmgenMarkup);

    if (
      !Number.isFinite(markup) ||
      markup < 0 ||
      markup > 1000
    ) {
      setMessage("Enter a valid markup percentage.");
      return;
    }

    setSmmgenImporting(true);
    setMessage("");

    try {
      const response = await fetch("/api/admin/smmgen-import", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "import",
          serviceId: smmgenService.service,
          markupPercent: markup,
          autoSync: smmgenAutoSync,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "Unable to import SMMGen service."
        );
      }

      setMessage("SMMGen service imported successfully.");
      setSmmgenServiceId("");
      setSmmgenMarkup("25");
      setSmmgenService(null);
      setSmmgenResult("");

      await loadServices();
      await loadCategories();
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Unable to import SMMGen service."
      );
    } finally {
      setSmmgenImporting(false);
    }
  }
  async function saveService(event: React.FormEvent) {
    event.preventDefault();

    setSaving(true);
    setMessage("");

    try {
      const payload = {
        name: form.name,
        platform: form.platform,
        category: form.category,
        description: form.description,
        rate: form.rate,
        min: form.min,
        max: form.max,
        enabled: form.enabled,
        refill: form.refill,
        providerId: form.providerId,
        providerName: form.providerName,
      };

      const response = await fetch("/api/admin/services", {
        method: editingId ? "PATCH" : "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(
          editingId
            ? {
                id: editingId,
                ...payload,
              }
            : payload
        ),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "Unable to save service."
        );
      }

      setMessage(
        editingId
          ? `Service #${editingId} updated successfully.`
          : `Service #${data.service.id} created successfully.`
      );

      resetForm();
      await loadServices();
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Unable to save service."
      );
    } finally {
      setSaving(false);
    }
  }

  async function toggleService(service: Service) {
    setMessage("");

    try {
      const response = await fetch("/api/admin/services", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          id: service.id,
          enabled: !service.enabled,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "Unable to update service."
        );
      }

      await loadServices();
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Unable to update service."
      );
    }
  }

  async function syncOrders() {
    setSyncing(true);
    setMessage("");

    try {
      const response = await fetch("/api/admin/orders/sync", {
        method: "POST",
        cache: "no-store",
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Unable to sync orders.");
      }

      setMessage(
        `Order sync complete. Checked ${data.checked}, updated ${data.updated}, failed ${data.failed}.`
      );
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Unable to sync orders."
      );
    } finally {
      setSyncing(false);
    }
  }

  async function deleteService(service: Service) {
    const confirmed = window.confirm(
      `Delete "${service.name}"? This only works if the service has no orders.`
    );

    if (!confirmed) return;

    try {
      const response = await fetch(
        `/api/admin/services?id=${service.id}`,
        {
          method: "DELETE",
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "Unable to delete service."
        );
      }

      setMessage(`Service #${service.id} deleted.`);

      await loadServices();
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Unable to delete service."
      );
    }
  }

  return (
    <main className="min-h-screen bg-slate-50 bg-[#070a11] text-slate-900">
      <header className="border-b border-gray-200 bg-[#090c14]/90 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
          <div>
            <h1 className="text-lg font-bold tracking-tight">
              Dream<span className="text-blue-500">SMM</span>
            </h1>

            <p className="text-[11px] text-slate-500">
              Administration Panel
            </p>
          </div>

          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-blue-600/20 text-sm font-bold text-blue-400 ring-1 ring-blue-500/20">
            A
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-6 py-8">
        <div className="mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
          <div>
            <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-blue-500/20 bg-blue-50 px-3 py-1 text-xs font-medium text-blue-400">
              <span className="h-1.5 w-1.5 rounded-full bg-blue-400" />
              Admin Panel
            </div>

            <h2 className="text-2xl font-bold tracking-tight">
              Service Management
            </h2>

            <p className="mt-1 text-sm text-slate-500">
              Manage services and provider configuration.
            </p>
          </div>

          <div className="flex gap-2">
            <button
              onClick={syncOrders}
              disabled={syncing}
              className="rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-slate-900 shadow-sm transition hover:bg-blue-700 transition hover:bg-blue-500 disabled:opacity-50"
            >
              {syncing ? "Syncing..." : "Sync Orders"}
            </button>

            <button
              onClick={loadServices}
              disabled={loading}
              className="rounded-lg border border-gray-200 bg-white px-4 py-2.5 text-sm font-medium text-slate-400 shadow-sm transition hover:bg-gray-50 transition hover:bg-gray-200 disabled:opacity-50"
            >
              Refresh
            </button>
          </div>
        </div>

        {message && (
          <div className="mb-6 flex items-center justify-between rounded-xl border border-blue-100 bg-blue-50 px-4 py-3 text-sm text-blue-700 shadow-sm">
            <span>{message}</span>

            <button
              onClick={() => setMessage("")}
              className="ml-4 text-blue-400 hover:text-slate-900"
            >
              â”œÃ¢â•žÃ†â”œÃ¥Î“Ã‡Ã–â”œÃ¢â”¬Ã³â”œÃ³Î“Ã‡Ãœâ”¬Â¼â”œÃ³Î“Ã©Â¼â”¬Â¥
            </button>
          </div>
        )}

        <section className="mb-6 rounded-2xl border border-teal-100 bg-gradient-to-br from-teal-50 to-blue-50 p-5 shadow-sm">
          <div className="mb-3">
            <h3 className="text-lg font-semibold">Import from MicoSMM</h3>
            <p className="mt-0.5 text-xs text-slate-500">
              Enter only the provider service ID. Details are fetched automatically.
            </p>
          </div>

          <div className="grid gap-3 md:grid-cols-[1fr_160px_auto]">
            <input
              value={providerServiceId}
              onChange={(e) => setProviderServiceId(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") fetchProviderService();
              }}
              className={inputClass}
              placeholder="MicoSMM Service ID e.g. 12345"
              inputMode="numeric"
            />

            <input
              type="number"
              min="0"
              step="0.01"
              value={providerMarkup}
              onChange={(e) => setProviderMarkup(e.target.value)}
              className={inputClass}
              placeholder="Markup %"
            />

            <button
              type="button"
              onClick={fetchProviderService}
              disabled={importing}
              className="rounded-xl bg-teal-600 px-5 py-2.5 text-sm font-semibold text-slate-900 transition hover:bg-teal-500 disabled:opacity-50"
            >
              {importing ? "Fetching..." : "Fetch Service"}
            </button>
          </div>

          <label className="mt-3 inline-flex cursor-pointer items-center gap-2 text-xs text-slate-500">
            <input
              type="checkbox"
              checked={providerAutoSync}
              onChange={(e) => setProviderAutoSync(e.target.checked)}
            />
            Automatically update my selling price when provider rate changes
          </label>

          {importedService && (
            <div className="mt-4 rounded-xl border border-gray-200 bg-gray-50 p-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="font-semibold text-slate-900">
                    {importedService.name}
                  </p>
                  <p className="mt-0.5 text-xs text-slate-500">
                    Provider ID #{importedService.service}
                    {importedService.category
                      ? ` â”¬â•– ${importedService.category}`
                      : ""}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={importProviderService}
                  disabled={importing}
                  className="rounded-xl bg-blue-600 px-4 py-2.5 text-xs font-bold text-slate-900 transition hover:bg-blue-500 disabled:opacity-50"
                >
                  {importing ? "Importing..." : "Add Service"}
                </button>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
                <div className="rounded-lg bg-gray-100 p-3">
                  <p className="text-[10px] text-slate-500">Provider Rate</p>
                  <p className="mt-1 text-sm font-semibold text-gray-900">
                    â”œÃ¢â”¬Ã³â”œÃ³Î“Ã©Â¼â”¼Ã­â”œÃ©â”¬â•£{importedService.rate}/1k
                  </p>
                </div>
                <div className="rounded-lg bg-gray-100 p-3">
                  <p className="text-[10px] text-slate-500">Your Markup</p>
                  <p className="mt-1 text-sm font-semibold text-teal-700">
                    {providerMarkup || "0"}%
                  </p>
                </div>
                <div className="rounded-lg bg-gray-100 p-3">
                  <p className="text-[10px] text-slate-500">Selling Rate</p>
                                      <p className="mt-1 text-sm font-semibold text-green-700">
                      â‚¹{(
                        Number(smmgenService?.rate ?? 0) * (1 + (Number(smmgenMarkup) || 0) / 100)
                      ).toFixed(4)}
                      /1k
                    </p>
                </div>
                <div className="rounded-lg bg-gray-100 p-3">
                <p className="text-[10px] text-slate-500">Average Time</p>
                <p className="mt-1 text-sm font-semibold text-blue-700">
                  {vipsmmService?.averageTime || "N/A"}
                </p>
              </div>
              <div className="rounded-lg bg-gray-100 p-3">
                  <p className="text-[10px] text-slate-500">Limits</p>
                  <p className="mt-1 text-sm font-semibold text-gray-900">
                    {importedService.min.toLocaleString()}-{importedService.max.toLocaleString()}
                    {importedService.max.toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
          )}
        </section>


        <section className="mb-6 rounded-2xl border border-teal-100 bg-teal-50/70 p-5 shadow-sm">
          <div className="mb-3">
            <h3 className="text-lg font-semibold">
              Import from SMMGen
            </h3>
            <p className="mt-0.5 text-xs text-slate-500">
              Enter the SMMGen service ID. Details are fetched automatically.
            </p>
          </div>

          <div className="grid gap-3 md:grid-cols-[1fr_160px_auto]">
            <input
              type="number"
              min="0"
              value={smmgenServiceId}
              onChange={(e) => setSmmgenServiceId(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") fetchSmmgenService();
              }}
              className={inputClass}
              placeholder="SMMGen Service ID e.g. 12345"
              inputMode="numeric"
            />

            <input
              type="number"
              min="0"
              step="0.01"
              value={smmgenMarkup}
              onChange={(e) => setSmmgenMarkup(e.target.value)}
              className={inputClass}
              placeholder="Markup %"
            />

            <button
              type="button"
              onClick={fetchSmmgenService}
              disabled={smmgenImporting}
              className="rounded-xl bg-teal-600 px-5 py-2.5 text-sm font-semibold text-slate-900 transition hover:bg-teal-500 disabled:opacity-50"
            >
              {smmgenImporting ? "Fetching..." : "Fetch Service"}
            </button>
          </div>

          <label className="mt-3 inline-flex cursor-pointer items-center gap-2 text-xs text-slate-500">
            <input
              type="checkbox"
              checked={smmgenAutoSync}
              onChange={(e) => setSmmgenAutoSync(e.target.checked)}
            />
            Automatically update my selling price when provider rate changes
          </label>

          {smmgenService && (
            <div className="mt-4 rounded-xl border border-gray-200 bg-gray-50 p-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="font-semibold text-slate-900">
                    {smmgenService.name}
                  </p>

                  <p className="mt-0.5 text-xs text-slate-500">
                    Provider ID #{smmgenService.service}
                    {smmgenService.category
                      ? ` â”¬â•– ${smmgenService.category}`
                      : ""}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={importSmmgenService}
                  disabled={smmgenImporting}
                  className="rounded-xl bg-teal-600 px-4 py-2.5 text-xs font-bold text-slate-900 transition hover:bg-teal-500 disabled:opacity-50"
                >
                  {smmgenImporting ? "Importing..." : "Add Service"}
                </button>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
                <div className="rounded-lg bg-gray-100 p-3">
                  <p className="text-[10px] text-slate-500">
                    Provider Rate
                  </p>
                  <p className="mt-1 text-sm font-semibold text-gray-900">
                    Î“Ã©â•£{(Number(smmgenService.rate)).toFixed(4)}/1k
                  </p>
                </div>

                <div className="rounded-lg bg-gray-100 p-3">
                  <p className="text-[10px] text-slate-500">
                    Your Markup
                  </p>
                  <p className="mt-1 text-sm font-semibold text-teal-700">
                    {smmgenMarkup || "0"}%
                  </p>
                </div>

                <div className="rounded-lg bg-gray-100 p-3">
                  <p className="text-[10px] text-slate-500">
                    Selling Rate
                  </p>
                  <p className="mt-1 text-sm font-semibold text-green-700">
                    Î“Ã©â•£{(
                      Number(smmgenService.rate) *
                      (1 + (Number(smmgenMarkup) || 0) / 100)
                    ).toFixed(4)}
                    /1k
                  </p>
                </div>

                <div className="rounded-lg bg-gray-100 p-3">
                  <p className="text-[10px] text-slate-500">
                    Limits
                  </p>
                  <p className="mt-1 text-sm font-semibold text-gray-900">
                    {smmgenService.min.toLocaleString()}-
                    {smmgenService.max.toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
          )}
        </section>
        <section className="mb-6 rounded-2xl border border-blue-100 bg-blue-50/70 p-5 shadow-sm">
          <div className="mb-3">
            <h3 className="text-lg font-semibold">
              Import from MKAPI
            </h3>
            <p className="mt-0.5 text-xs text-slate-500">
              Enter only the MKAPI service ID. Details are fetched automatically.
            </p>
          </div>

          <div className="grid gap-3 md:grid-cols-[1fr_160px_auto]">
            <input
              type="number"
              min="0"
              value={mkapiServiceId}
              onChange={(e) => setMkapiServiceId(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") fetchMkapiService();
              }}
              className={inputClass}
              placeholder="MKAPI Service ID e.g. 12345"
              inputMode="numeric"
            />

            <input
              type="number"
              min="0"
              step="0.01"
              value={mkapiMarkup}
              onChange={(e) => setMkapiMarkup(e.target.value)}
              className={inputClass}
              placeholder="Markup %"
            />

            <button
              type="button"
              onClick={fetchMkapiService}
              disabled={mkapiImporting}
              className="rounded-xl bg-blue-600 px-5 py-2.5 text-sm font-semibold text-slate-900 transition hover:bg-blue-500 disabled:opacity-50"
            >
              {mkapiImporting ? "Fetching..." : "Fetch Service"}
            </button>
          </div>

          <label className="mt-3 inline-flex cursor-pointer items-center gap-2 text-xs text-slate-500">
            <input
              type="checkbox"
              checked={mkapiAutoSync}
              onChange={(e) => setMkapiAutoSync(e.target.checked)}
            />
            Automatically update my selling price when provider rate changes
          </label>

          {mkapiService && (
            <div className="mt-4 rounded-xl border border-gray-200 bg-gray-50 p-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="font-semibold text-slate-900">
                    {mkapiService.name}
                  </p>
                  <p className="mt-0.5 text-xs text-slate-500">
                    Provider ID #{mkapiService.service}
                    {mkapiService.category
                      ? ` â”¬â•– ${mkapiService.category}`
                      : ""}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={importMkapiService}
                  disabled={mkapiImporting}
                  className="rounded-xl bg-blue-600 px-4 py-2.5 text-xs font-bold text-slate-900 transition hover:bg-blue-500 disabled:opacity-50"
                >
                  {mkapiImporting ? "Importing..." : "Add Service"}
                </button>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
                <div className="rounded-lg bg-gray-100 p-3">
                  <p className="text-[10px] text-slate-500">
                    Provider Rate
                  </p>
                  <p className="mt-1 text-sm font-semibold text-gray-900">
                    â”œÃ¢â”¬Ã³â”œÃ³Î“Ã©Â¼â”¼Ã­â”œÃ©â”¬â•£{mkapiService.rate}/1k
                  </p>
                </div>

                <div className="rounded-lg bg-gray-100 p-3">
                  <p className="text-[10px] text-slate-500">
                    Your Markup
                  </p>
                  <p className="mt-1 text-sm font-semibold text-teal-700">
                    {mkapiMarkup || "0"}%
                  </p>
                </div>

                <div className="rounded-lg bg-gray-100 p-3">
                  <p className="text-[10px] text-slate-500">
                    Selling Rate
                  </p>
                  <p className="mt-1 text-sm font-semibold text-green-700">
                    â”œÃ¢â”¬Ã³â”œÃ³Î“Ã©Â¼â”¼Ã­â”œÃ©â”¬â•£{(
                      Number(mkapiService.rate) *
                      (1 + (Number(mkapiMarkup) || 0) / 100)
                    ).toFixed(4)}
                    /1k
                  </p>
                </div>

                <div className="rounded-lg bg-gray-100 p-3">
                  <p className="text-[10px] text-slate-500">
                    Average Time
                  </p>
                  <p className="mt-1 text-sm font-semibold text-blue-700">
                    {mkapiService.averageTime || "N/A"}
                  </p>
                </div>
                <div className="rounded-lg bg-gray-100 p-3">
                  <p className="text-[10px] text-slate-500">
                    Average Time
                  </p>
                  <p className="mt-1 text-sm font-semibold text-blue-700">
                    {mkapiService.averageTime || "N/A"}
                  </p>
                </div>
                <div className="rounded-lg bg-gray-100 p-3">
                  <p className="text-[10px] text-slate-500">
                    Limits
                  </p>
                  <p className="mt-1 text-sm font-semibold text-gray-900">
                    {Number(mkapiService.min).toLocaleString()}-{Number(mkapiService.max).toLocaleString()}
                    {Number(mkapiService.max).toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
          )}

          {mkapiResult && (
            <div className="mt-4 rounded-xl border border-blue-100 bg-blue-50 px-4 py-3 text-xs text-blue-700">
              {mkapiResult}
            </div>
          )}
        </section>
<section className="mb-6 rounded-2xl border border-blue-100 bg-blue-50/70 p-5 shadow-sm">
          <div className="mb-3">
            <h3 className="text-lg font-semibold">
              Import from VIPSMM
            </h3>
            <p className="mt-0.5 text-xs text-slate-500">
              Enter only the VIPSMM service ID. Details are fetched automatically.
            </p>
          </div>

          <div className="grid gap-3 md:grid-cols-[1fr_160px_auto]">
            <input
              type="number"
              min="0"
              value={vipsmmServiceId}
              onChange={(e) => setVipsmmServiceId(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") fetchVipsmmService();
              }}
              className={inputClass}
              placeholder="VIPSMM Service ID e.g. 12345"
              inputMode="numeric"
            />

            <input
              type="number"
              min="0"
              step="0.01"
              value={vipsmmMarkup}
              onChange={(e) => setVipsmmMarkup(e.target.value)}
              className={inputClass}
              placeholder="Markup %"
            />

            <button
              type="button"
              onClick={fetchVipsmmService}
              disabled={vipsmmImporting}
              className="rounded-xl bg-blue-600 px-5 py-2.5 text-sm font-semibold text-slate-900 transition hover:bg-blue-500 disabled:opacity-50"
            >
              {vipsmmImporting ? "Fetching..." : "Fetch Service"}
            </button>
          </div>

          <label className="mt-3 inline-flex cursor-pointer items-center gap-2 text-xs text-slate-500">
            <input
              type="checkbox"
              checked={vipsmmAutoSync}
              onChange={(e) => setVipsmmAutoSync(e.target.checked)}
            />
            Automatically update my selling price when provider rate changes
          </label>

          {vipsmmService && (
            <div className="mt-4 rounded-xl border border-gray-200 bg-gray-50 p-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="font-semibold text-slate-900">
                    {vipsmmService.name}
                  </p>
                  <p className="mt-0.5 text-xs text-slate-500">
                    Provider ID #{vipsmmService.service}
                    {vipsmmService.category
                      ? ` â”¬â•– ${vipsmmService.category}`
                      : ""}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={importVipsmmService}
                  disabled={vipsmmImporting}
                  className="rounded-xl bg-blue-600 px-4 py-2.5 text-xs font-bold text-slate-900 transition hover:bg-blue-500 disabled:opacity-50"
                >
                  {vipsmmImporting ? "Importing..." : "Add Service"}
                </button>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
                <div className="rounded-lg bg-gray-100 p-3">
                  <p className="text-[10px] text-slate-500">
                    Provider Rate
                  </p>
                  <p className="mt-1 text-sm font-semibold text-gray-900">
                    â”œÃ¢â”¬Ã³â”œÃ³Î“Ã©Â¼â”¼Ã­â”œÃ©â”¬â•£{vipsmmService.rate}/1k
                  </p>
                </div>

                <div className="rounded-lg bg-gray-100 p-3">
                  <p className="text-[10px] text-slate-500">
                    Your Markup
                  </p>
                  <p className="mt-1 text-sm font-semibold text-teal-700">
                    {vipsmmMarkup || "0"}%
                  </p>
                </div>

                <div className="rounded-lg bg-gray-100 p-3">
                  <p className="text-[10px] text-slate-500">
                    Selling Rate
                  </p>
                  <p className="mt-1 text-sm font-semibold text-green-700">
                    â”œÃ¢â”¬Ã³â”œÃ³Î“Ã©Â¼â”¼Ã­â”œÃ©â”¬â•£{(
                      Number(vipsmmService.rate) *
                      (1 + (Number(vipsmmMarkup) || 0) / 100)
                    ).toFixed(4)}
                    /1k
                  </p>
                </div>

                <div className="rounded-lg bg-gray-100 p-3">
                  <p className="text-[10px] text-slate-500">
                    Average Time
                  </p>
                  <p className="mt-1 text-sm font-semibold text-blue-700">
                    {vipsmmService.averageTime || "N/A"}
                  </p>
                </div>
                <div className="rounded-lg bg-gray-100 p-3">
                  <p className="text-[10px] text-slate-500">
                    Average Time
                  </p>
                  <p className="mt-1 text-sm font-semibold text-blue-700">
                    {vipsmmService.averageTime || "N/A"}
                  </p>
                </div>
                <div className="rounded-lg bg-gray-100 p-3">
                  <p className="text-[10px] text-slate-500">
                    Limits
                  </p>
                  <p className="mt-1 text-sm font-semibold text-gray-900">
                    {Number(vipsmmService.min).toLocaleString()}-{Number(vipsmmService.max).toLocaleString()}
                    {Number(vipsmmService.max).toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
          )}

          {vipsmmResult && (
            <div className="mt-4 rounded-xl border border-blue-100 bg-blue-50 px-4 py-3 text-xs text-blue-700">
              {vipsmmResult}
            </div>
          )}
        </section>
        <div className="grid gap-6 lg:grid-cols-[360px_minmax(0,1fr)]">
          <section className="h-fit rounded-2xl border border-gray-200 bg-white p-5 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold">
                  {editingId
                    ? `Edit Service #${editingId}`
                    : "Add Service"}
                </h3>

                <p className="mt-1 text-xs text-slate-500">
                  Provider ID is the provider's service ID.
                </p>
              </div>

              {editingId && (
                <button
                  onClick={resetForm}
                  className="text-xs text-slate-500 hover:text-slate-900"
                >
                  Cancel
                </button>
              )}
            </div>

            <form
              onSubmit={saveService}
              className="mt-5 space-y-3"
            >
              <Field label="Service Name">
                <input
                  value={form.name}
                  onChange={(e) =>
                    updateForm("name", e.target.value)
                  }
                  className={inputClass}
                  placeholder="Instagram Followers"
                  required
                />
              </Field>

              <div className="grid grid-cols-2 gap-3">
                <Field label="Platform">
                  <input
                    value={form.platform}
                    onChange={(e) =>
                      updateForm("platform", e.target.value)
                    }
                    className={inputClass}
                    placeholder="Instagram"
                    required
                  />
                </Field>

 <Field label="Category">
  <div className="flex gap-2">
    <select
      value={form.category}
      onChange={(e) => updateForm("category", e.target.value)}
      className={inputClass}
    >
      <option value="">Select category</option>

      {categories.map((category) => (
        <option key={category.id} value={category.name}>
          {category.name}
        </option>
      ))}
    </select>

    <button
      type="button"
      onClick={() => setShowCreateCategory((value) => !value)}
      className="shrink-0 rounded-lg border border-gray-200 bg-white px-3 py-2 text-xs font-semibold text-slate-400 shadow-sm transition hover:bg-gray-50 transition hover:bg-gray-200"
    >
      + New
    </button>
  </div>

  {showCreateCategory && (
    <div className="mt-3 rounded-xl border border-gray-200 bg-gray-50 p-4">
      <input
        type="text"
        value={newCategoryName}
        onChange={(e) => setNewCategoryName(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") createCategory();
        }}
        className={inputClass}
        placeholder="Enter new category name"
      />

      <div className="mt-2 flex gap-2">
        <select
          value={newCategoryPlatform}
          onChange={(e) => setNewCategoryPlatform(e.target.value)}
          className={inputClass}
        >
          <option value="Instagram">Instagram</option>
          <option value="YouTube">YouTube</option>
          <option value="TikTok">TikTok</option>
          <option value="Facebook">Facebook</option>
          <option value="Telegram">Telegram</option>
          <option value="Twitter">Twitter</option>
          <option value="Spotify">Spotify</option>
          <option value="Reddit">Reddit</option>
          <option value="Other">Other</option>
        </select>

        <button
          type="button"
          onClick={createCategory}
          className="shrink-0 rounded-xl bg-blue-600 px-4 py-2.5 text-xs font-bold text-slate-900 transition hover:bg-blue-500"
        >
          Create
        </button>
      </div>
    </div>
  )}
</Field>
              </div>

              <Field label="Description">
                <textarea
                  value={form.description}
                  onChange={(e) =>
                    updateForm("description", e.target.value)
                  }
                  className={`${inputClass} min-h-20 resize-none`}
                  placeholder="Service description..."
                />
              </Field>

              <Field label="Rate per 1,000">
                <input
                  type="number"
                  min="0"
                  step="0.0001"
                  value={form.rate}
                  onChange={(e) =>
                    updateForm("rate", e.target.value)
                  }
                  className={inputClass}
                  placeholder="25"
                  required
                />
              </Field>

              <div className="grid grid-cols-2 gap-3">
                <Field label="Minimum">
                  <input
                    type="number"
                    min="1"
                    value={form.min}
                    onChange={(e) =>
                      updateForm("min", e.target.value)
                    }
                    className={inputClass}
                    placeholder="100"
                    required
                  />
                </Field>

                <Field label="Maximum">
                  <input
                    type="number"
                    min="1"
                    value={form.max}
                    onChange={(e) =>
                      updateForm("max", e.target.value)
                    }
                    className={inputClass}
                    placeholder="100000"
                    required
                  />
                </Field>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <Field label="Provider Name">
                  <input
                    value={form.providerName}
                    onChange={(e) =>
                      updateForm(
                        "providerName",
                        e.target.value
                      )
                    }
                    className={inputClass}
                    placeholder="Provider A"
                  />
                </Field>

                <Field label="Provider Service ID">
                  <input
                    value={form.providerId}
                    onChange={(e) =>
                      updateForm(
                        "providerId",
                        e.target.value
                      )
                    }
                    className={inputClass}
                    placeholder="12345"
                  />
                </Field>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-gray-200 bg-white p-3 shadow-sm">
                  <input
                    type="checkbox"
                    checked={form.enabled}
                    onChange={(e) =>
                      updateForm(
                        "enabled",
                        e.target.checked
                      )
                    }
                  />

                  <span className="text-xs text-slate-400">
                    Enabled
                  </span>
                </label>

                <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-gray-200 bg-white p-3 shadow-sm">
                  <input
                    type="checkbox"
                    checked={form.refill}
                    onChange={(e) =>
                      updateForm(
                        "refill",
                        e.target.checked
                      )
                    }
                  />

                  <span className="text-xs text-slate-400">
                    Refill
                  </span>
                </label>
              </div>

              <button
                type="submit"
                disabled={saving}
                className="w-full rounded-xl bg-blue-600 px-4 py-3 text-sm font-semibold shadow-sm transition hover:bg-blue-700 transition hover:bg-blue-500 disabled:opacity-50"
              >
                {saving
                  ? "Saving..."
                  : editingId
                    ? "Update Service"
                    : "Create Service"}
              </button>
            </form>
          </section>

          <section>
            <div className="mb-3">
              <h3 className="text-lg font-semibold">
                Services
              </h3>

              <p className="mt-1 text-xs text-slate-500">
                {services.length} service
                {services.length === 1 ? "" : "s"} in database
              </p>
            </div>

            {loading ? (
              <div className="rounded-2xl border border-gray-200 bg-white p-10 text-center shadow-sm text-center text-sm text-slate-500">
                Loading services...
              </div>
            ) : services.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-gray-200 bg-white p-12 text-center">
                <p className="font-semibold text-slate-400">
                  No services yet
                </p>

                <p className="mt-2 text-sm text-slate-500">
                  Create your first service using the form.
                </p>
              </div>
            ) : (
              <div className="space-y-4">

                <details open className="overflow-hidden rounded-2xl border border-gray-200 bg-white">
                  <summary className="cursor-pointer list-none px-4 py-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-gray-900">
                        🟢 ENABLED SERVICES
                      </span>
                      <span className="text-xs text-slate-400">
                        {services.filter((service) => service.enabled).length}
                      </span>
                    </div>
                  </summary>

                  <div className="space-y-2 border-t border-gray-100 p-3">
                    {services.filter((service) => service.enabled).map((service) => (<article
                    key={service.id}
                    className="rounded-2xl border border-gray-200 bg-white p-4 transition hover:border-blue-300 hover:shadow-sm"
                  >
                    <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="text-xs font-bold text-blue-400">
                            #{service.id}
                          </span>

                          <span
                            className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${
                              service.enabled
                                ? "bg-green-500/10 text-green-400"
                                : "bg-red-500/10 text-red-400"
                            }`}
                          >
                            {service.enabled
                              ? "Enabled"
                              : "Disabled"}
                          </span>

                          {service.refill && (
                            <span className="rounded-full bg-cyan-500/10 px-2 py-0.5 text-[10px] font-medium text-cyan-400">
                              Refill
                            </span>
                          )}
                        </div>

                        <h4 className="mt-1.5 font-semibold text-gray-900">
                          {service.name}
                        </h4>

                        <p className="mt-0.5 text-xs text-slate-500">
                          {service.platform}
                          {service.category
                            ? ` â”¬â•– ${service.category}`
                            : ""}
                        </p>

                        <div className="mt-2 flex flex-wrap gap-1.5 text-[10px]">
                          <span className="rounded-md bg-gray-50 px-2 py-0.5 text-slate-500">
                            Rate â”œÃ¢â”¬Ã³â”œÃ³Î“Ã©Â¼â”¼Ã­â”œÃ©â”¬â•£{service.rate}/1k
                          </span>

                          <span className="rounded-md bg-gray-50 px-2 py-0.5 text-slate-500">
                            {service.min.toLocaleString()}-{service.max.toLocaleString()}
                            {service.max.toLocaleString()}
                          </span>

                          <span className="rounded-lg bg bg-pink-300:/20 px-2 py-1 text-slate-500">
                            {service.providerName ||
                              "No provider"}

                            {service.providerId
                              ? ` â”¬â•– ID ${service.providerId}`
                              : ""}
                          </span>
                        </div>
                      </div>

                      <div className="flex shrink-0 gap-1.5">
                        <button
                          onClick={() =>
                            toggleService(service)
                          }
                          className="rounded-lg border border-gray-200 bg-gray-100 px-2.5 py-1.5 text-[11px] text-slate-400 hover:bg-gray-200"
                        >
                          {service.enabled
                            ? "Disable"
                            : "Enable"}
                        </button>

                        <button
                          onClick={() =>
                            startEdit(service)
                          }
                          className="rounded-lg bg-blue-600 px-2.5 py-1.5 text-[11px] font-semibold text-slate-900 hover:bg-blue-500"
                        >
                          Edit
                        </button>

                        <button
                          onClick={() =>
                            deleteService(service)
                          }
                          className="rounded-lg border border-red-500/20 bg-red-500/[0.05] px-2.5 py-1.5 text-[11px] text-red-400 hover:bg-red-500/10"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  </article>                    ))}
                  </div>
                </details>

                <details className="overflow-hidden rounded-2xl border border-gray-200 bg-white">
                  <summary className="cursor-pointer list-none px-4 py-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-gray-900">
                        🔴 DISABLED SERVICES
                      </span>
                      <span className="text-xs text-slate-400">
                        {services.filter((service) => !service.enabled).length}
                      </span>
                    </div>
                  </summary>

                  <div className="space-y-2 border-t border-gray-100 p-3">
                    {services.filter((service) => !service.enabled).map((service) => (<article
                    key={service.id}
                    className="rounded-2xl border border-gray-200 bg-white p-4 transition hover:border-blue-300 hover:shadow-sm"
                  >
                    <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="text-xs font-bold text-blue-400">
                            #{service.id}
                          </span>

                          <span
                            className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${
                              service.enabled
                                ? "bg-green-500/10 text-green-400"
                                : "bg-red-500/10 text-red-400"
                            }`}
                          >
                            {service.enabled
                              ? "Enabled"
                              : "Disabled"}
                          </span>

                          {service.refill && (
                            <span className="rounded-full bg-cyan-500/10 px-2 py-0.5 text-[10px] font-medium text-cyan-400">
                              Refill
                            </span>
                          )}
                        </div>

                        <h4 className="mt-1.5 font-semibold text-gray-900">
                          {service.name}
                        </h4>

                        <p className="mt-0.5 text-xs text-slate-500">
                          {service.platform}
                          {service.category
                            ? ` â”¬â•– ${service.category}`
                            : ""}
                        </p>

                        <div className="mt-2 flex flex-wrap gap-1.5 text-[10px]">
                          <span className="rounded-md bg-gray-50 px-2 py-0.5 text-slate-500">
                            Rate â”œÃ¢â”¬Ã³â”œÃ³Î“Ã©Â¼â”¼Ã­â”œÃ©â”¬â•£{service.rate}/1k
                          </span>

                          <span className="rounded-md bg-gray-50 px-2 py-0.5 text-slate-500">
                            {service.min.toLocaleString()}-{service.max.toLocaleString()}
                            {service.max.toLocaleString()}
                          </span>

                          <span className="rounded-lg bg bg-pink-300:/20 px-2 py-1 text-slate-500">
                            {service.providerName ||
                              "No provider"}

                            {service.providerId
                              ? ` â”¬â•– ID ${service.providerId}`
                              : ""}
                          </span>
                        </div>
                      </div>

                      <div className="flex shrink-0 gap-1.5">
                        <button
                          onClick={() =>
                            toggleService(service)
                          }
                          className="rounded-lg border border-gray-200 bg-gray-100 px-2.5 py-1.5 text-[11px] text-slate-400 hover:bg-gray-200"
                        >
                          {service.enabled
                            ? "Disable"
                            : "Enable"}
                        </button>

                        <button
                          onClick={() =>
                            startEdit(service)
                          }
                          className="rounded-lg bg-blue-600 px-2.5 py-1.5 text-[11px] font-semibold text-slate-900 hover:bg-blue-500"
                        >
                          Edit
                        </button>

                        <button
                          onClick={() =>
                            deleteService(service)
                          }
                          className="rounded-lg border border-red-500/20 bg-red-500/[0.05] px-2.5 py-1.5 text-[11px] text-red-400 hover:bg-red-500/10"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  </article>                    ))}
                  </div>
                </details>

              </div>
            )}
          </section>
        </div>
      </div>
    </main>
  );
}
































